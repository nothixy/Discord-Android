package org.flval.discordwebview;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ValueCallback<Uri[]> UploadMessage;
    WebView discord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_main);
        WebView discord = (WebView) findViewById(R.id.webview);
/*        TextView channame = (TextView) findViewById(R.id.channame);
        ImageButton menu = (ImageButton) findViewById(R.id.imageButton);
        final Boolean[] peopleopen = {false};
        final Boolean[] menuopen = {false};
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!menuopen[0]) {
                    injectCSS("style_people_close.css");
                    peopleopen[0] = false;
                    injectCSS("style_menuleft_open.css");
                    menuopen[0] = true;
                } else {
                    injectCSS("style_menuleft_close.css");
                    menuopen[0] = false;
                }

            }
        });
        ImageButton people = (ImageButton) findViewById(R.id.imageButton2);
        people.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!peopleopen[0]) {
                    injectCSS("style_menuleft_close.css");
                    menuopen[0] = false;
                    injectCSS("style_people_open.css");
                    peopleopen[0] = true;
                } else {
                    injectCSS("style_people_close.css");
                    peopleopen[0] = false;
                }
            }
        });
*/

        List<String> perms = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.RECORD_AUDIO);
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!perms.isEmpty()) {
            int MY_PERMISSIONS_ALL = 1;
            ActivityCompat.requestPermissions(MainActivity.this, perms.toArray(new String[perms.size()]), MY_PERMISSIONS_ALL);
        }

        super.onCreate(savedInstanceState);




        // Here we want the desktop site
        String newUA= "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36";
        discord.getSettings().setUserAgentString(newUA);
        discord.getSettings().setMediaPlaybackRequiresUserGesture(false);
        CookieManager.getInstance().setAcceptCookie(true);
        discord.getSettings().setDomStorageEnabled(true);
        discord.getSettings().setAllowFileAccessFromFileURLs(true);
        discord.getSettings().setAllowFileAccess(true);
        discord.getSettings().setAllowUniversalAccessFromFileURLs(true);

        // Enable Javascript
        discord.getSettings().setJavaScriptEnabled(true);

        discord.setWebContentsDebuggingEnabled(true);
        // Add a WebViewClient
 //       discord.setWebViewClient(new WebViewClient() {
        discord.setWebChromeClient(new WebChromeClient() {

            String channelprefix = "@CHANNEL :";
            public boolean onConsoleMessage(ConsoleMessage response) {
                if (response.message().startsWith(channelprefix)) {
                    String chantext = response.message().substring(channelprefix.length());
                    Log.d("Channel", chantext);
//                    channame.setText(chantext);
                } else if (response.message() == "SETTINGSON") {
                    replace("on");
                } else if (response.message() == "SETTINGSOFF") {
                    replace("off");
                }
                return true;
            }

            private void replace(String sw) {
                if (sw == "on") {
                    Log.d("SETTINGS ON BINGO", "WIN");
                } else if(sw == "off") {
                    Log.d("SETTINGS OFF BINGO", "WIN");
                }
            }
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return false;
            }
            public void onPermissionRequest(PermissionRequest request) {
            // Generally you want to check which permissions you are granting
                request.grant(request.getResources());
                }
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) {
                    injectCSS("style.css");
                    injectCSS("style_people_close.css");
                    injectCSS("style_menuleft_close.css");
                    discord.loadUrl("javascript:(function() { console.log('" + channelprefix +"', document.getElementsByClassName('title-29uC1r').item(0).textContent) })()");
                }
            }
            private ValueCallback<Uri[]> mFilePathCallback;
            private final static int FILECHOOSER_RESULTCODE = 1;
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                if (mFilePathCallback != null) {
                    mFilePathCallback.onReceiveValue(null);
                }
                mFilePathCallback = filePathCallback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                MainActivity.this.startActivityForResult(Intent.createChooser(i, "File Chooser"), FILECHOOSER_RESULTCODE );
                return true;
            }

        });
        // Load a webpage
        discord.loadUrl("https://discordapp.com/login");
    }

    // Inject CSS method: read style.css from assets folder
// Append stylesheet to document head
    private void injectCSS(String cssfile) {
        try {
            InputStream css = getAssets().open(cssfile);
            byte[] cssbuffer = new byte[css.available()];
            css.read(cssbuffer);
            css.close();
            String cssencoded = Base64.encodeToString(cssbuffer, Base64.NO_WRAP);
            discord.loadUrl("javascript:(function() {" +
                    "var parent = document.getElementsByTagName('head').item(0);" +
                    "var style = document.createElement('style');" +
                    "style.type = 'text/css';" +
                    // Tell the browser to BASE64-decode the string into your script !!!
                    "style.innerHTML = window.atob('" + cssencoded + "');" +
                    "parent.appendChild(style);" +
                    "})()");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}